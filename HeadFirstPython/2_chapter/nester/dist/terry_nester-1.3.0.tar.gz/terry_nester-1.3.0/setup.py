from distutils.core import setup

setup(
        name            =   'terry_nester',
        version         =   '1.3.0',
        py_modules      =   ['terry_nester'],
        author          =   'terry.zeng',
        author_email    =   'terryzeng98@gmail.com',
        url             =   'http://www.headfirstlabs.com',
        description     =   'A simple printer of nested lists',
    )
