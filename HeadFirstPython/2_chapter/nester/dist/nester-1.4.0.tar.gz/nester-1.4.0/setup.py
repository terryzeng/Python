from distutils.core import setup

setup(
        name            =   'nester',
        version         =   '1.4.0',
        py_modules      =   ['nester'],
        author          =   'terry.zeng',
        author_email    =   'terryzeng98@gmail.com',
        url             =   'http://www.headfirstlabs.com',
        description     =   'A simple printer of nested lists',
    )
